const puppeteer = require('puppeteer');
const player = require('play-sound')((opts = {}));
const cron = require('node-cron');
const { USER_AGENT, REQUEST_URL } = require('./const');

const checkAppointment = async () => {
   const browser = await puppeteer.launch({ headless: true });
   const page = await browser.newPage();

   await page.setUserAgent(USER_AGENT);
   await page.evaluateOnNewDocument(() => {
      Object.defineProperty(navigator, 'plugins', {
         get: () => [1, 2, 3, 4, 5, 6, 7, 8],
      });
   });

   const url = REQUEST_URL + Date.now();
   console.log(`Requesting ${url}...`);

   const currentTabSelector = 'div.antcl_wizardSteps.dynamic > ul > li.antcl_active > div';
   const nextButtonSelector = `.ui-button-text.ui-c`;

   await page.goto(url);
   await page.waitForSelector(nextButtonSelector, { visible: true });
   await page.click(nextButtonSelector);
   await page.waitForTimeout(5000);

   console.log("Page opened: ", await page.title());

   const currentTabEl = await page.$(currentTabSelector);
   const currentTab = await (await currentTabEl.getProperty('textContent')).jsonValue();

   console.log("Current tab is: ", currentTab);
   const isThereAppointment = currentTab == 3;
   if (isThereAppointment) {
      await page.waitForTimeout(1000);
      await page.screenshot({ path: `${Date.now()}.png` });
   }

   await browser.close();

   return isThereAppointment;
};

const playMusic = (timeout) => {
   player.play('./music.mp3', { timeout }, (err) => console.error(err));
};

(async () => {
   // every seconds -> * * * * *
   // every 30 seconds -> */30 * * * * *
   const job = cron.schedule('*/30 * * * * *', async () => {
      const response = await checkAppointment();
      if (response) {
         const timeout = 30 * 1000;
         playMusic(timeout);
         setTimeout(() => job.stop(), timeout);
      }
   });
})();
